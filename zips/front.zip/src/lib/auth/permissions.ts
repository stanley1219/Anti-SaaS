import { User } from '@/types/auth';

export function hasPermission(user: User | null, permission: string): boolean {
    return user?.permissions.includes(permission) ?? false;
}

export function hasAnyPermission(user: User | null, permissions: string[]): boolean {
    return permissions.some((p) => hasPermission(user, p));
}
