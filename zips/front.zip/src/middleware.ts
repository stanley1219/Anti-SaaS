import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;

    // Extract tenant from path: /t/{tenantId}/...
    const match = pathname.match(/^\/t\/([^/]+)/);
    const tenantId = match?.[1];

    const response = NextResponse.next();

    // Set tenantId cookie if found in path
    if (tenantId) {
        response.cookies.set('tenantId', tenantId, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            path: '/',
        });
    }

    // Protected routes: /t/*
    if (pathname.startsWith('/t/')) {
        const hasRefreshToken = request.cookies.has('refreshToken');

        if (!hasRefreshToken) {
            // No refresh token cookie, redirect to login
            const url = new URL('/login', request.url);
            return NextResponse.redirect(url);
        }
    }

    return response;
}

export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - api (API routes)
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         */
        '/((?!api|_next/static|_next/image|favicon.ico).*)',
    ],
};
