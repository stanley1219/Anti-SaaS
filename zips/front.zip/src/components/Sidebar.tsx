'use client';

import Link from 'next/link';
import { useAuth } from '@/lib/auth/context';
import { useTenant } from '@/lib/tenant/context';
import { hasPermission } from '@/lib/auth/permissions';

export default function Sidebar() {
    const { user } = useAuth();
    const { tenantId } = useTenant();

    if (!tenantId) return null;

    const base = `/t/${tenantId}`;

    return (
        <div className="w-64 border-r h-screen p-4 flex flex-col space-y-2">
            <Link href={`${base}/expenses`} className="p-2 hover:bg-gray-100 block">My Expenses</Link>
            {hasPermission(user, 'expense:approve') && (
                <Link href={`${base}/approvals`} className="p-2 hover:bg-gray-100 block">Approvals</Link>
            )}
        </div>
    );
}
