'use strict';

const express = require('express');
const roleService = require('../../domain/auth/role-service');
const tenantService = require('../../domain/tenant/tenant-service');
const userRepository = require('../../domain/user/user-repository');
const { requireRoleLevel } = require('../../api/middleware/auth');
const { validate } = require('../../api/middleware/validator');
const { ValidationError } = require('../../core/errors');

const router = express.Router();

/**
 * 1. SYSTEM-LEVEL ROUTES (Universal Root Admin only: level 0)
 */

// List all tenants
router.get('/tenants', requireRoleLevel(0), async (req, res, next) => {
    try {
        const tenants = await tenantService.listTenants();
        res.success(tenants);
    } catch (err) {
        next(err);
    }
});

// Create tenant + first admin
router.post('/tenants', requireRoleLevel(0), async (req, res, next) => {
    try {
        const { tenant, admin } = req.body;
        if (!tenant || !admin) {
            throw new ValidationError('Tenant and Admin data are required');
        }
        const result = await tenantService.createTenantWithAdmin(tenant, admin);
        res.success(result);
    } catch (err) {
        next(err);
    }
});

/**
 * 2. TENANT-LEVEL ADMIN ROUTES (Tenant Root Admin only: level 1)
 */

router.get('/users', requireRoleLevel(1), async (req, res, next) => {
    try {
        const users = await userRepository.listUsersByTenant(req.user.tenantId);
        res.success(users);
    } catch (err) {
        next(err);
    }
});

router.post('/users', requireRoleLevel(1), async (req, res, next) => {
    try {
        const { email, password } = req.body;
        const authService = require('../../domain/auth/auth-service');
        const passwordHash = await authService.hashPassword(password);

        const user = await userRepository.createUser(req.user.tenantId, {
            email,
            passwordHash
        });
        res.success(user);
    } catch (err) {
        next(err);
    }
});

router.patch('/users/:id', requireRoleLevel(1), async (req, res, next) => {
    try {
        const user = await userRepository.updateUser(req.user.tenantId, req.params.id, req.body);
        res.success(user);
    } catch (err) {
        next(err);
    }
});

router.delete('/users/:id', requireRoleLevel(1), async (req, res, next) => {
    try {
        await userRepository.deleteUser(req.user.tenantId, req.params.id);
        res.success({ message: 'User deleted successfully' });
    } catch (err) {
        next(err);
    }
});

/**
 * 3. ROLE ASSIGNMENT ROUTES
 */

router.get('/roles', requireRoleLevel(2), async (req, res, next) => {
    try {
        const roles = await userRepository.listRolesByTenant(req.user.tenantId);
        res.success(roles);
    } catch (err) {
        next(err);
    }
});

router.post('/users/:id/roles', requireRoleLevel(2), async (req, res, next) => {
    try {
        const { roleId } = req.body;
        await roleService.assignRole(req.user.tenantId, req.user, req.params.id, roleId);
        res.success({ message: 'Role assigned successfully' });
    } catch (err) {
        next(err);
    }
});

router.delete('/users/:id/roles/:roleId', requireRoleLevel(2), async (req, res, next) => {
    try {
        await roleService.revokeRole(req.user.tenantId, req.user, req.params.id, req.params.roleId);
        res.success({ message: 'Role revoked successfully' });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
