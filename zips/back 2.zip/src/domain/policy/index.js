'use strict';

const expensePolicy = require('./expense.policy');

module.exports = {
    expense: expensePolicy
};
