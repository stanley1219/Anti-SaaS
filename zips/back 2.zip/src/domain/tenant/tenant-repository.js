'use strict';

const db = require('../../core/database/pool');
const { systemQuery } = require('../../core/database/tenant-query');

/**
 * Repository for Tenant-related database operations.
 */
class TenantRepository {
    /**
     * List all tenants in the system.
     */
    async listAll() {
        const query = 'SELECT * FROM tenants ORDER BY created_at DESC';
        const result = await systemQuery(query);
        return result.rows;
    }

    /**
     * Create a new tenant.
     */
    async create({ name, slug, status = 'active' }) {
        const query = `
            INSERT INTO tenants (name, slug, status)
            VALUES ($1, $2, $3)
            RETURNING *
        `;
        const result = await systemQuery(query, [name, slug, status]);
        return result.rows[0];
    }

    /**
     * Find a tenant by ID.
     */
    async findById(tenantId) {
        const query = 'SELECT * FROM tenants WHERE tenant_id = $1';
        const result = await systemQuery(query, [tenantId]);
        return result.rows[0];
    }

    /**
     * Find a tenant by slug.
     */
    async findBySlug(slug) {
        const query = 'SELECT * FROM tenants WHERE slug = $1';
        const result = await systemQuery(query, [slug]);
        return result.rows[0];
    }
}

module.exports = new TenantRepository();
