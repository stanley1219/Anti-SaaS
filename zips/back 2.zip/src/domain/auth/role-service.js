'use strict';

const userRepository = require('../user/user-repository');
const { ForbiddenError, ValidationError } = require('../../core/errors');
const logger = require('../../core/logger');

/**
 * Service for managing Role hierarchy and assignments.
 */
class RoleService {
    /**
     * Assign a role to a user, strictly enforcing hierarchy.
     * @param {string} tenantId - Context tenant
     * @param {Object} assignerUser - The user performing the action { id, roles: [{ role_level, can_assign_roles }] }
     * @param {string} targetUserId - The user receiving the role
     * @param {string} roleId - The role to be assigned
     */
    async assignRole(tenantId, assignerUser, targetUserId, roleId) {
        // 1. Fetch the target role details
        const roleToAssign = await userRepository.getRoleById(roleId);
        if (!roleToAssign) {
            throw new ValidationError('Role not found');
        }

        // 2. Enforce Hierarchy & Assignment Rules
        // Rule: A user can assign a role if:
        // - They have role level 0 (Universal Admin)
        // - OR The roleId is explicitly in their role's 'can_assign_roles' array
        // - OR They are level 1 (Tenant Root Admin) and target role is level > 1

        const assignerRoles = await userRepository.getUserRoles(assignerUser.tenantId, assignerUser.id);

        const hasAuthority = assignerRoles.some(ar => {
            if (ar.role_level === 0) return true; // Universal Admin can do anything
            if (ar.can_assign_roles && ar.can_assign_roles.includes(roleId)) return true;
            if (ar.role_level === 1 && roleToAssign.role_level > 1) return true; // Root Admin can assign lower roles
            return false;
        });

        if (!hasAuthority) {
            logger.warn({
                assignerId: assignerUser.id,
                targetUserId,
                roleId,
                tenantId
            }, 'Access Denied: Hierarchy violation during role assignment');
            throw new ForbiddenError('Insufficient privileges to assign this role');
        }

        // 3. Prevent Privilege Escalation
        // Assigner should not be able to assign a role with higher level (lower num) than their own highest role
        const highestAssignerLevel = Math.min(...assignerRoles.map(r => r.role_level));
        if (roleToAssign.role_level < highestAssignerLevel) {
            throw new ForbiddenError('Cannot assign a role higher than your own level');
        }

        // 4. Perform Assignment
        await userRepository.assignUserRole(tenantId, targetUserId, roleId);

        logger.info({
            assignerId: assignerUser.id,
            targetUserId,
            roleId,
            tenantId
        }, 'Role assigned successfully');
    }

    /**
     * Revoke a role from a user.
     */
    async revokeRole(tenantId, assignerUser, targetUserId, roleId) {
        // Similar hierarchy checks would go here for production hardening
        // For phase 2, we implement the core removal
        await userRepository.removeUserRole(tenantId, targetUserId, roleId);

        logger.info({
            assignerId: assignerUser.id,
            targetUserId,
            roleId,
            tenantId
        }, 'Role revoked successfully');
    }

    /**
     * Validate if a user has at least one of the required roles by level.
     */
    async hasRequiredRoleLevel(tenantId, userId, maxAllowedLevel) {
        const roles = await userRepository.getUserRoles(tenantId, userId);
        return roles.some(r => r.role_level <= maxAllowedLevel);
    }
}

module.exports = new RoleService();
