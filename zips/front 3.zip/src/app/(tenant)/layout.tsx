'use client';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header' ;
import { useAuth } from '@/lib/auth/context';
import { useRouter, usePathname } from 'next/navigation';
import { useEffect } from 'react';

export default function TenantLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (isLoading) return;

    // 🚫 CRITICAL: tenant layout must never interfere with admin routes
    if (pathname.startsWith('/admin')) return;

    if (!user) {
      router.push('/login');
      return;
    }

    // Universal Root Admin must NOT stay in tenant app
    if (user.primaryRole?.level === 0) {
      router.push('/admin/tenants');
      return;
    }
  }, [isLoading, user, pathname, router]);

  if (isLoading) return null;

  return <>{children}</>;
}