'use client';

import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth/context';
import { useEffect } from 'react';

export default function DashboardPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login');
    }
  }, [isLoading, user, router]);

  if (isLoading || !user) return null;

  const roleLevel = user.primaryRole?.level;

  return (
    <div style={{ padding: '24px' }}>
      <h1>Dashboard</h1>
      <p>Welcome, {user.email}</p>

      {/* UNIVERSAL ROOT ADMIN */}
      {roleLevel === 0 && (
        <div style={{ marginTop: '24px' }}>
          <button
            style={buttonStyle}
            onClick={() => router.push('/admin/tenants')}
          >
            Manage Tenants & Tenant Root Admins
          </button>
        </div>
      )}

      {/* TENANT ROOT ADMIN */}
      {roleLevel === 1 && (
        <div style={{ marginTop: '24px' }}>
          <button
            style={buttonStyle}
            onClick={() => router.push('/admin/users')}
          >
            Manage Users & Roles
          </button>
        </div>
      )}

      {/* TENANT ADMIN */}
      {roleLevel === 2 && (
        <div style={{ marginTop: '24px' }}>
          <button
            style={buttonStyle}
            onClick={() => router.push('/admin/users')}
          >
            View Tenant Users
          </button>
          <p style={{ marginTop: '8px', color: '#666' }}>
            You have read-only access to tenant users.
          </p>
        </div>
      )}

      {/* TENANT USER */}
      {roleLevel === 3 && (
        <p style={{ marginTop: '24px', color: '#666' }}>
          You are logged in as a standard user.
        </p>
      )}
    </div>
  );
}

const buttonStyle = {
  padding: '10px 16px',
  fontSize: '16px',
  cursor: 'pointer',
};