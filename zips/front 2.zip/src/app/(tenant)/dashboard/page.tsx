'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth/context';

export default function DashboardPage() {
  const { isLoading, isAuthenticated } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isLoading, isAuthenticated, router]);

  if (isLoading) {
    // keep layout height → NO layout shift
    return <div className="dashboard-skeleton" />;
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* 🔴 PASTE YOUR ORIGINAL DASHBOARD UI HERE */}
    </>
  );
}