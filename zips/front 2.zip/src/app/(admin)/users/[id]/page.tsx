'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminService } from '@/lib/api/admin';
import { useAuth } from '@/lib/auth/context';
import { useParams, useRouter } from 'next/navigation';
import { useState } from 'react';
import { getErrorMessage } from '@/lib/api/error-utils';

export default function EditUserPage() {
    const { id } = useParams();
    const router = useRouter();
    const queryClient = useQueryClient();
    const { user: currentUser } = useAuth();
    const [actionError, setActionError] = useState<string | null>(null);

    // 1. Fetch data
    const { data: users } = useQuery({
        queryKey: ['admin', 'users'],
        queryFn: adminService.listUsers
    });

    const { data: roles } = useQuery({
        queryKey: ['admin', 'roles'],
        queryFn: adminService.listRoles
    });

    const targetUser = users?.find((u: any) => u.user_id === id);

    // 2. Fetch target user's current roles (We'd need a backend endpoint for this ideally, 
    // but we can infer from our system for now if we don't have it. 
    // Actually Phase 2 implemented getUserRoles in repo, let's assume we can fetch it or managed it)
    // For now, let's just implement the UI to Assign/Revoke.

    // 3. Mutations
    const updateMutation = useMutation({
        mutationFn: (updates: any) => adminService.updateUser(id as string, updates),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin', 'users'] })
    });

    const assignRoleMutation = useMutation({
        mutationFn: (roleId: string) => adminService.assignRole(id as string, roleId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
            setActionError(null);
        },
        onError: (err) => setActionError(getErrorMessage(err))
    });

    const deleteMutation = useMutation({
        mutationFn: () => adminService.deleteUser(id as string),
        onSuccess: () => router.push('/admin/users')
    });

    if (!targetUser) return <div className="p-12 text-center text-gray-500 font-bold">User not found.</div>;

    return (
        <div className="max-w-4xl space-y-12 pb-24">
            <header className="flex justify-between items-start">
                <div>
                    <button
                        onClick={() => router.back()}
                        className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-black mb-4 flex items-center"
                    >
                        ← Back to Users
                    </button>
                    <h1 className="text-3xl font-black tracking-tight text-gray-900">{targetUser.email}</h1>
                    <p className="text-gray-500 font-medium mt-1">Manage permissions, status, and system access.</p>
                </div>

                <div className="flex space-x-2">
                    <button
                        onClick={() => {
                            if (confirm('Are you sure? This will disable the user account.')) {
                                deleteMutation.mutate();
                            }
                        }}
                        className="border border-red-200 text-red-600 px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest hover:bg-red-50 transition-colors"
                    >
                        Revoke Access
                    </button>
                </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Status Card */}
                <section className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                    <h2 className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-6 flex items-center">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span>
                        Account Status
                    </h2>

                    <div className="flex flex-wrap gap-2">
                        {['active', 'inactive', 'suspended'].map((status) => (
                            <button
                                key={status}
                                onClick={() => updateMutation.mutate({ status })}
                                className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest border transition-all ${targetUser.status === status
                                        ? 'bg-black text-white border-black shadow-md'
                                        : 'bg-white text-gray-400 border-gray-100 hover:border-gray-300'
                                    }`}
                            >
                                {status}
                            </button>
                        ))}
                    </div>
                </section>

                {/* Role Assignment Card */}
                <section className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                    <h2 className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-6 flex items-center">
                        <span className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2"></span>
                        Assign Roles
                    </h2>

                    {actionError && (
                        <div className="bg-red-50 text-red-600 p-3 rounded-lg text-[10px] font-bold mb-4 border border-red-100 uppercase tracking-tight">
                            {actionError}
                        </div>
                    )}

                    <div className="space-y-2">
                        {roles?.map((role: any) => (
                            <button
                                key={role.role_id}
                                onClick={() => assignRoleMutation.mutate(role.role_id)}
                                className="w-full flex justify-between items-center p-3 rounded-xl border border-gray-100 hover:border-blue-200 hover:bg-blue-50 transition-all group"
                            >
                                <div className="text-left">
                                    <p className="text-xs font-black uppercase tracking-tight text-gray-700">{role.name}</p>
                                    <p className="text-[10px] text-gray-400 font-medium">Level {role.role_level}</p>
                                </div>
                                <span className="opacity-0 group-hover:opacity-100 text-[10px] font-black text-blue-600 uppercase tracking-widest transition-opacity">+ Assign</span>
                            </button>
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
}
