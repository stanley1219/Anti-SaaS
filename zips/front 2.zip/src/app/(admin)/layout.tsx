'use client';

import { useAuth } from '@/lib/auth/context';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import AdminSidebar from '@/components/AdminSidebar';
import Header from '@/components/Header';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const { user, isAuthenticated, isLoading } = useAuth();
    const router = useRouter();

    useEffect(() => {
        if (!isLoading) {
            if (!isAuthenticated) {
                router.push('/login');
            } else if (user?.primaryRole && user.primaryRole.level > 2) {
                // Not an admin, boot them back to dashboard
                router.push('/dashboard');
            }
        }
    }, [isLoading, isAuthenticated, user, router]);

    if (isLoading || !isAuthenticated || (user?.primaryRole && user.primaryRole.level > 2)) {
        return <div className="p-12 text-center text-gray-500 font-medium">Verifying administrative access...</div>;
    }

    return (
        <div className="flex min-h-screen">
            <AdminSidebar />
            <div className="flex-1 flex flex-col">
                <Header />
                <main className="p-8 max-w-6xl w-full mx-auto">
                    {children}
                </main>
            </div>
        </div>
    );
}
