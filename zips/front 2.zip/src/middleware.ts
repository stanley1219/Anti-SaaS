// import { NextResponse } from 'next/server';
// import type { NextRequest } from 'next/server';

// export function middleware(request: NextRequest) {
//     const { pathname } = request.nextUrl;
//     const hasRefreshToken = request.cookies.has('refreshToken');

//     // 1. Allow public static assets and system routes
//     if (
//         pathname.startsWith('/_next') ||
//         pathname.startsWith('/api/') ||
//         pathname.includes('.') ||
//         pathname === '/favicon.ico'
//     ) {
//         return NextResponse.next();
//     }

//     // 2. Public auth routes
//     const isAuthRoute = pathname === '/login' || pathname === '/register';

//     if (isAuthRoute) {
//         if (hasRefreshToken) {
//             // If already logged in, redirect to root which will then handle dashboard redirect
//             return NextResponse.redirect(new URL('/', request.url));
//         }
//         return NextResponse.next();
//     }

//     // 3. Protected routes: must have refresh token
//     if (!hasRefreshToken) {
//         const loginUrl = new URL('/login', request.url);
//         // Important: clear tenant session on login redirect to avoid mismatch
//         const response = NextResponse.redirect(loginUrl);
//         response.cookies.delete('tenantId');
//         return response;
//     }

//     return NextResponse.next();
// }

// export const config = {
//     matcher: [
//         /*
//          * Match all request paths except for the ones starting with:
//          * - api (API routes)
//          * - _next/static (static files)
//          * - _next/image (image optimization files)
//          * - favicon.ico (favicon file)
//          */
//         '/((?!api|_next/static|_next/image|favicon.ico).*)',
//     ],
// };

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const PUBLIC_PATHS = ['/login', '/register'];

export function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;

    // Allow public pages & system assets
    if (
        PUBLIC_PATHS.includes(pathname) ||
        pathname.startsWith('/_next') ||
        pathname.startsWith('/api') ||
        pathname === '/favicon.ico'
    ) {
        return NextResponse.next();
    }

    const hasRefreshToken = request.cookies.has('refreshToken');

    if (!hasRefreshToken) {
        return NextResponse.redirect(new URL('/login', request.url));
    }

    return NextResponse.next();
}

export const config = {
    matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};