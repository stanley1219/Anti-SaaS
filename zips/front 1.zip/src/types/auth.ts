import { z } from 'zod';

export const UserSchema = z.object({
    id: z.string().uuid(),
    tenantId: z.string().uuid(),
    email: z.string().email(),
    name: z.string().optional(),
    status: z.enum(['active', 'inactive']),
    permissions: z.array(z.string()),
});

export type User = z.infer<typeof UserSchema>;

export interface AuthState {
    user: User | null;
    accessToken: string | null;
    isAuthenticated: boolean;
    isLoading: boolean;
}
