'use strict';

const db = require('./pool');

/**
 * Base query helper that enforces tenant isolation.
 * Every query executed through this must provide a tenant_id.
 * 
 * @param {string} tenantId - The UUID of the tenant
 * @param {string} text - The SQL query
 * @param {Array} params - The query parameters
 * @returns {Promise<import('pg').QueryResult>}
 */
const tenantQuery = async (tenantId, text, params = []) => {
    if (!tenantId) {
        throw new Error('Tenant isolation violation: tenant_id is required for all database operations');
    }

    // Foundation note: This is the hook for Row-Level Security (RLS). 
    // For production, if using RLS, we would get a client from the pool
    // and run: 'SET LOCAL app.current_tenant_id = $1' within a transaction.

    return db.query(text, params);
};

module.exports = {
    tenantQuery,
};
