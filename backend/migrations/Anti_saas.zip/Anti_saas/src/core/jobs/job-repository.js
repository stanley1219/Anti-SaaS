'use strict';

const { tenantQuery } = require('../database/tenant-query');
const db = require('../database/pool');

class JobRepository {
    /**
     * Enqueue a new background job.
     */
    async enqueue(tenantId, type, payload, options = {}) {
        const { scheduledAt = new Date(), priority = 0 } = options;
        const query = `
      INSERT INTO background_jobs (
        tenant_id, type, payload, scheduled_at, priority, status
      )
      VALUES ($1, $2, $3, $4, $5, 'queued')
      RETURNING *
    `;
        const result = await tenantQuery(tenantId, query, [
            tenantId, type, JSON.stringify(payload), scheduledAt, priority
        ]);
        return result.rows[0];
    }

    /**
     * Pick up queued jobs and lock them for processing.
     * Atomic lock using SKIP LOCKED.
     */
    async pickAndLockJobs(limit = 1, lockId) {
        const query = `
      UPDATE background_jobs
      SET status = 'processing',
          locked_at = NOW(),
          locked_by = $1,
          attempts = attempts + 1
      WHERE job_id IN (
        SELECT job_id
        FROM background_jobs
        WHERE status IN ('queued', 'failed')
          AND attempts < $2
          AND (scheduled_at <= NOW() OR scheduled_at IS NULL)
          AND (locked_at IS NULL OR locked_at < NOW() - INTERVAL '5 minutes')
        ORDER BY priority DESC, scheduled_at ASC
        LIMIT $3
        FOR UPDATE SKIP LOCKED
      )
      RETURNING *
    `;
        // Using global pool because this crosses tenants to find work
        const config = require('../../config');
        const result = await db.query(query, [lockId, config.jobs.maxRetries, limit]);
        return result.rows;
    }

    /**
     * Mark a job as completed.
     */
    async complete(tenantId, jobId) {
        const query = `
      UPDATE background_jobs
      SET status = 'completed',
          locked_at = NULL,
          locked_by = NULL,
          completed_at = NOW()
      WHERE tenant_id = $1 AND job_id = $2
    `;
        await tenantQuery(tenantId, query, [tenantId, jobId]);
    }

    /**
     * Mark a job as failed and schedule retry.
     */
    async fail(tenantId, jobId, error, retryAt = null) {
        const query = `
      UPDATE background_jobs
      SET status = 'failed',
          locked_at = NULL,
          locked_by = NULL,
          last_error = $3,
          scheduled_at = COALESCE($4, NOW() + (INTERVAL '1 minute' * attempts * attempts))
      WHERE tenant_id = $1 AND job_id = $2
    `;
        await tenantQuery(tenantId, query, [tenantId, jobId, error, retryAt]);
    }
}

module.exports = new JobRepository();
