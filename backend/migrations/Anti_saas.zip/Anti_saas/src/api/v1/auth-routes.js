'use strict';

const express = require('express');
const authService = require('../../domain/auth/auth-service');
const { authenticate } = require('../../api/middleware/auth');
const { validate } = require('../../api/middleware/validator');

const router = express.Router();

const loginSchema = {
    body: {
        tenantId: { required: true },
        email: { required: true, type: 'string' },
        password: { required: true, type: 'string' }
    }
};

const refreshSchema = {
    body: {
        tenantId: { required: true },
        refreshToken: { required: true, type: 'string' }
    }
};

/**
 * Login endpoint
 */
router.post('/login', validate(loginSchema), async (req, res, next) => {
    try {
        const { tenantId, email, password } = req.body;
        const tokens = await authService.login(tenantId, email, password);
        res.success(tokens);
    } catch (err) {
        next(err);
    }
});

/**
 * Token refresh endpoint
 */
router.post('/refresh', validate(refreshSchema), async (req, res, next) => {
    try {
        const { tenantId, refreshToken } = req.body;
        const tokens = await authService.refresh(tenantId, refreshToken);
        res.success(tokens);
    } catch (err) {
        next(err);
    }
});

/**
 * Logout
 */
router.post('/logout', authenticate, async (req, res, next) => {
    try {
        const { refreshToken } = req.body;
        if (refreshToken) {
            await authService.logout(req.user.tenantId, refreshToken);
        }
        res.success({ message: 'Logged out successfully' });
    } catch (err) {
        next(err);
    }
});

/**
 * Me endpoint (Verify session)
 */
router.get('/me', authenticate, (req, res) => {
    res.success({
        user: {
            id: req.user.id,
            tenantId: req.user.tenantId,
            permissions: req.user.permissions
        }
    });
});

module.exports = router;
