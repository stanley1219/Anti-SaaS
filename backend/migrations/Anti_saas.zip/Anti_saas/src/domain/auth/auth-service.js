'use strict';

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const config = require('../../config');
const userRepository = require('../user/user-repository');
const logger = require('../../core/logger');

/**
 * Service for Authentication and Token Management.
 */
class AuthService {
    /**
     * Authenticate a user by email and password.
     * @param {string} tenantId 
     * @param {string} email 
     * @param {string} password 
     */
    async login(tenantId, email, password) {
        const user = await userRepository.findByEmail(tenantId, email);

        if (!user) {
            logger.warn({ tenantId, email }, 'Login failed: user not found');
            throw new Error('Invalid credentials');
        }

        if (user.status !== 'active') {
            logger.warn({ tenantId, userId: user.user_id, status: user.status }, 'Login failed: inactive user');
            throw new Error('User account is not active');
        }

        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            logger.warn({ tenantId, email }, 'Login failed: password mismatch');
            throw new Error('Invalid credentials');
        }

        // Resolve permissions to embed in JWT
        const permissions = await userRepository.getUserPermissions(tenantId, user.user_id);

        return this.generateTokens(tenantId, user.user_id, permissions);
    }

    /**
     * Refresh access tokens using a valid refresh token.
     * @param {string} tenantId 
     * @param {string} refreshToken 
     */
    async refresh(tenantId, refreshToken) {
        try {
            const decoded = jwt.verify(refreshToken, config.auth.refreshSecret);

            const session = await userRepository.findSession(tenantId, decoded.jti);
            if (!session || session.revoked_at || new Date(session.expires_at) < new Date()) {
                throw new Error('Session invalid or expired');
            }

            // Hash check to ensure token integrity (if stored hashed)
            // In this simple implementation, we assume jti uniqueness is enough, 
            // but rotation is better. Let's revoke the old one.
            await userRepository.revokeSession(tenantId, decoded.jti);

            const user = await userRepository.findById(tenantId, session.user_id);
            if (!user || user.status !== 'active') {
                throw new Error('User inactive or not found');
            }

            const permissions = await userRepository.getUserPermissions(tenantId, user.user_id);
            return this.generateTokens(tenantId, user.user_id, permissions);
        } catch (err) {
            logger.error({ err, tenantId }, 'Token refresh failed');
            throw new Error('Invalid refresh token');
        }
    }

    /**
     * Generate Access and Refresh tokens.
     */
    async generateTokens(tenantId, userId, permissions) {
        const tokenId = uuidv4();

        const accessToken = jwt.sign(
            {
                sub: userId,
                tid: tenantId,
                permissions
            },
            config.auth.accessSecret,
            { expiresIn: config.auth.accessExpiry }
        );

        const refreshToken = jwt.sign(
            {
                sub: userId,
                tid: tenantId,
                jti: tokenId
            },
            config.auth.refreshSecret,
            { expiresIn: config.auth.refreshExpiry }
        );

        // Store refresh token session in DB
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30); // 30 days

        await userRepository.saveRefreshToken(tenantId, userId, tokenId, null, expiresAt);

        return { accessToken, refreshToken };
    }

    /**
     * Revoke a specific session.
     */
    async logout(tenantId, refreshToken) {
        try {
            const decoded = jwt.verify(refreshToken, config.auth.refreshSecret);
            await userRepository.revokeSession(tenantId, decoded.jti);
        } catch (err) {
            // Ignore errors on logout
            logger.debug({ err }, 'Logout error (likely already expired)');
        }
    }

    /**
     * Hash a password for storage.
     */
    async hashPassword(password) {
        return bcrypt.hash(password, config.auth.passwordSaltRounds);
    }
}

module.exports = new AuthService();
