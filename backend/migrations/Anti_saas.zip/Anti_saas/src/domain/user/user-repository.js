'use strict';

const db = require('../../core/database/pool');
const { tenantQuery } = require('../../core/database/tenant-query');

/**
 * Repository for User-related database operations.
 * Strictly enforces tenant isolation.
 */
class UserRepository {
    /**
     * Find a user by email within a specific tenant.
     * @param {string} tenantId 
     * @param {string} email 
     */
    async findByEmail(tenantId, email) {
        const query = `
      SELECT user_id, tenant_id, email, password_hash, status
      FROM users
      WHERE tenant_id = $1 AND email = $2 AND deleted_at IS NULL
    `;
        const result = await tenantQuery(tenantId, query, [tenantId, email]);
        return result.rows[0];
    }

    /**
     * Find a user by ID within a specific tenant.
     * @param {string} tenantId 
     * @param {string} userId 
     */
    async findById(tenantId, userId) {
        const query = `
      SELECT user_id, tenant_id, email, status
      FROM users
      WHERE tenant_id = $1 AND user_id = $2 AND deleted_at IS NULL
    `;
        const result = await tenantQuery(tenantId, query, [tenantId, userId]);
        return result.rows[0];
    }

    /**
     * Get all permissions for a user across their assigned roles within a tenant.
     * @param {string} tenantId 
     * @param {string} userId 
     */
    async getUserPermissions(tenantId, userId) {
        const query = `
      SELECT DISTINCT rp.permission_key
      FROM user_roles ur
      JOIN role_permissions rp ON ur.role_id = rp.role_id AND ur.tenant_id = rp.tenant_id
      WHERE ur.tenant_id = $1 AND ur.user_id = $2
    `;
        const result = await tenantQuery(tenantId, query, [tenantId, userId]);
        return result.rows.map(row => row.permission_key);
    }

    /**
     * Store a refresh token for a user.
     * @param {string} tenantId 
     * @param {string} userId 
     * @param {string} tokenId - Unique identifier for the refresh token
     * @param {string} tokenHash - Hashed version of the token
     * @param {Date} expiresAt 
     */
    async saveRefreshToken(tenantId, userId, tokenId, tokenHash, expiresAt) {
        // Note: Assuming a sessions table exists per SCHEMA_DESIGN.md
        const query = `
      INSERT INTO sessions (tenant_id, session_id, user_id, token_hash, expires_at)
      VALUES ($1, $2, $3, $4, $5)
    `;
        await tenantQuery(tenantId, query, [tenantId, tokenId, userId, tokenHash, expiresAt]);
    }

    /**
     * Find a session by its token ID.
     * @param {string} tenantId 
     * @param {string} tokenId 
     */
    async findSession(tenantId, tokenId) {
        const query = `
      SELECT session_id, tenant_id, user_id, token_hash, expires_at, revoked_at
      FROM sessions
      WHERE tenant_id = $1 AND session_id = $2
    `;
        const result = await tenantQuery(tenantId, query, [tenantId, tokenId]);
        return result.rows[0];
    }

    /**
     * Revoke a specific session/refresh token.
     * @param {string} tenantId 
     * @param {string} tokenId 
     */
    async revokeSession(tenantId, tokenId) {
        const query = `
      UPDATE sessions
      SET revoked_at = NOW()
      WHERE tenant_id = $1 AND session_id = $2
    `;
        await tenantQuery(tenantId, query, [tenantId, tokenId]);
    }
}

module.exports = new UserRepository();
