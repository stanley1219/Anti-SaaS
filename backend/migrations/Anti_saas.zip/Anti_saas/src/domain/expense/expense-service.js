'use strict';

const expenseRepository = require('./expense-repository');
const policyEngine = require('../policy/policy-stub');
const workflowService = require('../workflow/workflow-service');
const auditService = require('../../core/audit/audit-service');
const billingService = require('../billing/billing-service');
const jobRepository = require('../../core/jobs/job-repository');
const logger = require('../../core/logger');
const { getClient } = require('../../core/database/pool');
const { ValidationError, ForbiddenError, NotFoundError, ConflictError } = require('../../core/errors');
const { tenantQuery } = require('../../core/database/tenant-query');

/**
 * Service for Expense lifecycle and business logic.
 */
class ExpenseService {
    /**
     * Create a new expense in DRAFT pulse.
     */
    async createExpense(tenantId, userId, data) {
        this.validateExpenseData(data);
        await this.validateCategory(tenantId, data.categoryId);

        const expense = await expenseRepository.create(tenantId, {
            ...data,
            userId,
            status: 'DRAFT'
        });

        await auditService.log({
            tenantId,
            userId,
            action: 'EXPENSE_CREATE',
            entityType: 'expense',
            entityId: expense.expense_id,
            metadata: { amount: expense.amount, currency: expense.currency }
        });

        // Record usage for billing
        await billingService.recordUsage(tenantId, 'expenses_created');

        // Enqueue background OCR processing
        await jobRepository.enqueue(tenantId, 'ocr', { expenseId: expense.expense_id });

        return expense;
    }

    /**
     * Update an existing DRAFT expense.
     */
    async updateExpense(tenantId, userId, expenseId, data, userPermissions) {
        const expense = await expenseRepository.findById(tenantId, expenseId);

        if (!expense) throw new NotFoundError('Expense not found');

        // Ownership/Admin check
        if (expense.user_id !== userId && !userPermissions.includes('expense:view_all')) {
            throw new ForbiddenError('You do not own this expense');
        }

        if (expense.status !== 'DRAFT' && expense.status !== 'REJECTED') {
            throw new ConflictError('Cannot edit an expense that is already submitted or approved');
        }

        this.validateExpenseData(data);
        if (data.categoryId) {
            await this.validateCategory(tenantId, data.categoryId);
        }

        const updated = await expenseRepository.update(tenantId, expenseId, data);

        await auditService.log({
            tenantId,
            userId,
            action: 'EXPENSE_UPDATE',
            entityType: 'expense',
            entityId: expenseId,
            metadata: { changes: data }
        });

        return updated;
    }

    /**
     * Submit an expense for approval.
     */
    async submitExpense(tenantId, userId, expenseId) {
        const expense = await expenseRepository.findById(tenantId, expenseId);

        if (!expense) throw new NotFoundError('Expense not found');
        if (expense.user_id !== userId) throw new ForbiddenError('You do not own this expense');

        // Idempotency: If already submitted, just return success
        if (expense.status === 'SUBMITTED' || expense.status === 'APPROVED') {
            return expense;
        }

        // Call Policy Engine Stub
        const policyResult = await policyEngine.evaluate(tenantId, expense);

        if (!policyResult.pass) {
            throw new ValidationError(`Policy Violation: ${policyResult.violations.join(', ')}`);
        }

        // Transactional submit
        const client = await getClient();
        try {
            await client.query('BEGIN');

            // Re-verify status under lock if needed, but here we just proceed
            const submittedExpense = await expenseRepository.updateStatus(tenantId, expenseId, 'SUBMITTED', client);

            await auditService.log({
                tenantId,
                userId,
                action: 'EXPENSE_SUBMIT',
                entityType: 'expense',
                entityId: expenseId,
                metadata: { policyWarnings: policyResult.warnings }
            });

            // Instantiate approval workflow
            await workflowService.startWorkflow(tenantId, expenseId, client);

            await client.query('COMMIT');
            return submittedExpense;
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    }

    /**
     * Get expense with ownership verification.
     */
    async getExpense(tenantId, userId, expenseId, userPermissions) {
        const expense = await expenseRepository.findById(tenantId, expenseId);
        if (!expense) return null;

        if (expense.user_id !== userId && !userPermissions.includes('expense:view_all')) {
            throw new ForbiddenError();
        }

        return expense;
    }

    /**
     * List expenses with tenant and user scoping.
     */
    async listExpenses(tenantId, userId, filters, userPermissions) {
        const searchFilters = { ...filters };

        // If user doesn't have 'view_all', force their own userId
        if (!userPermissions.includes('expense:view_all') && !userPermissions.includes('expense:audit_view')) {
            searchFilters.userId = userId;
        }

        return expenseRepository.list(tenantId, searchFilters);
    }

    /**
     * Validates that category belongs to the tenant.
     */
    async validateCategory(tenantId, categoryId) {
        const query = 'SELECT 1 FROM expense_categories WHERE tenant_id = $1 AND category_id = $2 AND deleted_at IS NULL';
        const result = await tenantQuery(tenantId, query, [tenantId, categoryId]);
        if (result.rowCount === 0) {
            throw new ValidationError('Invalid or inaccessible category');
        }
    }

    /**
     * Basic validation for expense fields.
     */
    validateExpenseData(data) {
        if (!data.amount || data.amount <= 0) throw new ValidationError('Invalid amount');
        if (!data.currency || data.currency.length !== 3) throw new ValidationError('Invalid currency code');
        if (!data.categoryId) throw new ValidationError('Category is required');
        if (!data.merchant) throw new ValidationError('Merchant is required');
        if (!data.date) throw new ValidationError('Date is required');
    }
}

module.exports = new ExpenseService();
